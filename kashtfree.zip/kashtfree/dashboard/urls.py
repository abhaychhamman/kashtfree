 
from django.urls import path
from . import views

urlpatterns = [
   
    
    path('dashboard', views.Dashboard,name="dashboard"),
    path('linkData/', views.linkData,name="linkData"),
    path('deleteData/', views.deleteData,name="deleteData"),
]
