 
from django.urls import path
from . import views

urlpatterns = [
   
    
    path('generateLink/', views.GenerateLinkView,name="generateLink"),
    path('formcolumn/<str:user>/<str:linkName>/<int:column>', views.FormColumn,name="formcolumn"),
    path('form/<str:linkName>', views.FormGenerator,name="formcolumn"),
]
