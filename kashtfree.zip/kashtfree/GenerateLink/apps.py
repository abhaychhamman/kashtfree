from django.apps import AppConfig


class GeneratelinkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'GenerateLink'
