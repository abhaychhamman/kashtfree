from django.contrib import admin
from .models import Verification,MobileVerification
# Register your models here.
admin.site.register(Verification)
admin.site.register(MobileVerification)
