from django.contrib import admin
from .models import Dev
# Register your models here.
admin.site.register(Dev)
